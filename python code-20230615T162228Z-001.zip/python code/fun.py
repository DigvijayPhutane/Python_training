""""""
"""
class student:
    def __init__(self,stdi,stname,stadd,semail):
        self.stud_id=stid
        self.stud_name=stname
        self.stud_add=stadd
        self.stud_email=stemail

s1=(101,'poonam','pune','pr@gmail.com')
s1=(102,'shiavnsh','mumbai','shivanshyadav@gmail.com')
print(s1)
______________________________________________
"""
x = 200