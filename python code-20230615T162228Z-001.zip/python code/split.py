#str
s = 'simple and easy'
print(s.split())
for i in s.split () : # returns words
    print(i)
s = 'simple and easy'
print(s.split())
for i in s: # returns single element
    print(i)
