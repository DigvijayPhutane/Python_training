percentage = float (input('Enter your percentage:'))

if percentage >=85:
    print('you got Distinction')
elif percentage>=75:
    print('you got First rank')
elif percentage>=65:
    print('you got second class')
elif percentage>=55:
    print('you got pass class')
else:
    print('sorry you r fail')
