a = 200
b = 55
c = 550
if a > b or a > c:
    print( 'At least one of the condition is true')
    print(a>b)
    print(b>c)
    print(a>c)
    print(c>b)
    print(c>a)
    print(b<a)
    print(b>a)