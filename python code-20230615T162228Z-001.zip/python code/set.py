myset = {'devansh', 'siddhi', 'shivansh', 'mauli', 'pooja'}
print(myset)
print(len(myset))