
brand = 'asus'
if brand=='mac':
    print('Rs.230000')
elif brand=='Dell':
    print('Rs.900000')
elif brand=='hp':
    print('Rs.65000')
else:
    print ('sorry we only have 3 options')


