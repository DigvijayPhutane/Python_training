x = 11

if x > 10:
    print('Above ten,')
    if x > 20:
        print('and also above 21!')
    else:
        print('but not above 20.')
