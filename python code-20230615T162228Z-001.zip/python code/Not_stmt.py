a = 2
b = 3
if not a > b:
    print(' a is NOT greater than b')
else:
    print('b is NOT greater than a')