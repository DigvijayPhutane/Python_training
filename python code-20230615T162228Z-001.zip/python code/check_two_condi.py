name = 'laxmi'
if name == 'laxmi':
    print(name)
else:
    print('name is not found')