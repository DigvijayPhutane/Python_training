# when we want to test 3 condition the go with
# if <condition>: elif<condition>: else:
# PS: check 2 numbers are equal><
num_1 = 20
num_2 = 20
if num_1 == num_2:
    print('both are equal numbers')
elif num_1> num_2:
    print('number 1 is maximum')
    print('number 2 is maximum')
