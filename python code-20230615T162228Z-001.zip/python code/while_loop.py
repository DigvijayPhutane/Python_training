""""""
"""

#PS: print 1-10 numbers using while loop

num = 1
while num<11:
    print(num)
    num = num+1
____________________________________
#PS : print 1=10 even number using while loop
num = 2
while num <=20:
    print(num)
    num = num+2
_____________________________________________________________
#PS: print ur name 5 times using while loopnum = 1
while num <6:
    print('shivdev')
    num = num+1

num = 1
while num <= 20:
#print(num)
if num%2 == 0:
 print(num)
 num = num+1
"""
k = [100,3,4,56,7,8,13,15,60]
# PS: fetch odd numbers using while loop

#num%2!=0
print(len(k)-1)
index = 0
while index < len(k):
    print(k[index])
if k[index]%2 !=0:
    print(k[index])
    index = index+1


