""""""
"""
def sample():
    return 1
print(sample)

# here sample is <function sample>

# lambda
s = lambda x:1
print(s)
# here s is <function <lambda?>>
_____________________________________
# filter
purpose it to filter the values based on the condition 
given in a function
will get the result wherever the condition becomes
True
n = [2,3,-4,5,-10,-1,3,5]
# filter -ve values
f = lambda num: num>0
print(list(filter(f,n)))
______________________________________
"""
