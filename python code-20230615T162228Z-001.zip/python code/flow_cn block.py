
num = 10
if num == 10:
 print('hello')

    
    
    
      
