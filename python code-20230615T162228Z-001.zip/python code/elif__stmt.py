a = 500
b = 500
if b > a:
    print('b is greater than a')
if a > b:
    print ('a is greater than b')
elif a==b:
    print('a and b are equal')