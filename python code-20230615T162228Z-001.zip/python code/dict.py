

#dict
"""
d = {'Name':'poonam','place':'mumbai','num':10}
for i in (d.keys()): #returns only keys
    print(i)
_________________________________________________

d = {'Name':'poonam','place':'mumbai','num':10}
print (d['Name'])
for i in d:
    print(i,d[i])
d = {'Name':'poonam','place':'mumbai','num':10}
print(d.items())

for i in d.items():
    print(i)

d = {'Name':'poonam','place':'Mumbai','num':10}
#print(d.values())
for i in d.values(): #returns only values
    print(i)

"""
d = {'Name':'poonam','place':'mumbai','num':10}
#print(d['place])
# d[key] == value
for key in d:
    print(key,d[key])


