i = 0
while i < 101:
    i += 1
    if i == 2:
        continue
    print(i)
else:
    print('i is no longer less than 101')