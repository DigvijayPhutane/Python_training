""""""
from tempfile import tempdir

"""
def test1():
    price=100
    print("value price in test1 function :",price)

def test2():
    price=200
    print("value price in test function :",price)


test1()
test2()
_____________________________________________

x = 200
def sample():
    x=100
    #global x
    #nonlocal x
    x = x + 400
    print('inside a function:',x)
sample()
print('outside a function:',x)
sample()
_____________________________________________

class sample:
    a = 10 # public
    _b = 20 # protected
    __c = 30 # private

s = sample()
print(s.a)
#print(s.a,s.c)
print(s._b)
print(s.__c)
_________________________________________


def test():
    temp = 122
    if temp < 90:
        return 'fever'
    else:
     if temp > 100:
        return ' u need RTPCR'
     else:
        return'normal'
print(test())
_____________________________________

def test():
    #print(100+200)
     return 100+200
print(test())
__________________________________________

def calc():
    a = 10
    b = 20
    return a+b, a-b, a*b
output = calc()
print(output)
_________________________________________
def sample():
    x = 100

    return x
print(sample())
____________________________________________
"""



