X = ('poonam', 'manjiri', 'maithili', 'mauli')
print(X)
print(len(X))