# list
for i in [10,20,30]:
    print(i)






























