#num = 0
# take a number from user
num = int(input('enter the number:'))
# PS:write a python code to check number is +ve or -ve
if num>0:
    print('Its a +ve number')
else:
    print('Its a -ve number')
