#PS:print(1-20)even numbers using for loop

for num in range(1,21):
    print(num)
if num%2 == 0:
    print(num,'is even number')
else:
    print(num,'is odd number')
