i = 1
while i < 11:
     print(i)
     if i == 6:
        break
     i+= 1