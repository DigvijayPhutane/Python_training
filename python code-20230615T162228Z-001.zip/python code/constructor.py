""""""
"""
class Student:

    def __init__(self,name):
        print('Inside Constructor')
        self.name = name
        print('All variables initialized')

    def show(self):
        print('hello, my name is ', self.name)


s1 = Student('Emma')
s1.show()
_______________________________________________________
"""

class company:

    def __init__(self):
        self.name = 'pynative'
        self.address ='ABC Street'

    def show(self):
        print('name:')