a = 330
b = 400
if b > a:
    print('b is greater than a') #
