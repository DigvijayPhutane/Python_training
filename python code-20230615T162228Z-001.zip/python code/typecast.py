num = int(input('Enter number:'))
# input's default data type is str
# multiply number by 100
print(num*100)
print(type(num))
print(int(num)*100)
print(num*100)

