a = 500
b = 100
if a > b:
    print('hello poonam ')
else:
   print('b is greater than a')