P = ['apple', 'banana', 'cherry', 'apple']
print(P)
print(len(P))